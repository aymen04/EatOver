<?php
echo "si tu lis ça c'est que php fonctionne sur github";
?>